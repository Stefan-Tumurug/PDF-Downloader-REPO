﻿namespace PdfDownloader.Core.Application;

public enum DownloadStatus
{
    Downloaded,
    SkippedExists,
    Failed
}